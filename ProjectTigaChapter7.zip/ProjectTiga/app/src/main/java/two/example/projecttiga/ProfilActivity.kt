package two.example.projecttiga

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_profil.*
import two.example.projecttiga.RoomData.PeminjamanDatabase
import two.example.projecttiga.model.Buku11ResponseItem

class ProfilActivity : AppCompatActivity() {
    var pinjamDb : PeminjamanDatabase? = null
    lateinit var viewModel : ViewModelPinjam
    lateinit var userManager : UserManager
    lateinit var bookAdapter : PinjamAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

        pinjamDb = PeminjamanDatabase.getInstance(this)
        userManager = UserManager(this)


        var username = ""
        userManager.username.asLiveData().observe(this){
            username = it
            getAllPinjaman(username)
        }

    }


    fun getAllPinjaman(username : String){
        viewModel = ViewModelProvider(this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(ViewModelPinjam::class.java)


        viewModel.getLiveBukuObserver().observe(this@ProfilActivity){
            if (it != null){
                rvBuku2.layoutManager = LinearLayoutManager(this@ProfilActivity)
                bookAdapter = PinjamAdapter (){
                    val pindah = Intent(this@ProfilActivity, DetailActivity::class.java)
                    val detailBuku : Buku11ResponseItem = Buku11ResponseItem("asdasd", it.idBuku.toString(),it.judul, it.penerbit,it.penulis,it.sampul,
                        it.sinopsis, 0, it.tanggalRilis)
                    pindah.putExtra("detailbuku", detailBuku)
                    startActivity(pindah)
                }
                rvBuku2.adapter = bookAdapter
                bookAdapter.setDataFilm(it)
                bookAdapter.notifyDataSetChanged()
            }else{

            }

        }
        viewModel.getPinjamLive(username)


    }

}