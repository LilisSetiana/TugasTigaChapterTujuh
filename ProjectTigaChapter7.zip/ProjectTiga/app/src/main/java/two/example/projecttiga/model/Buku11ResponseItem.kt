package two.example.projecttiga.model


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Buku11ResponseItem(
    @SerializedName("address")
    val address: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("judul")
    val image: String,
    @SerializedName("penerbit")
    val name: String,
    @SerializedName("panulis")
    val pass: String,
    @SerializedName("sampul")
    val password: String,
    @SerializedName("sinopsis")
    val umur: Int,
    @SerializedName("tanggalpinjam")
    val username: String
) : Parcelable