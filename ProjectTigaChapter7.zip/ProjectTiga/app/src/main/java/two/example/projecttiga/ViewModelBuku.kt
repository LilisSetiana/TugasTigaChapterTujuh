package two.example.projecttiga

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import two.example.projecttiga.model.Buku11ResponseItem
import two.example.projecttiga.network.ApiClient

class ViewModelBuku : ViewModel() {

    var liveDataBuku : MutableLiveData<List<Buku11ResponseItem>?> = MutableLiveData()

    //================================= LIVE DATA BUKU ================================================//
    fun getLiveBukuObserver() : MutableLiveData<List<Buku11ResponseItem>?> {
        return liveDataBuku
    }


    //================================= API CLIENT BUKU ===============================================//
    fun makeApiFilm(){
        ApiClient.instance.getAllBuku()
            .enqueue(object : Callback<List<Buku11ResponseItem>> {
                override fun onResponse(
                    call: Call<List<Buku11ResponseItem>>,
                    response: Response<List<Buku11ResponseItem>>
                ) {
                    when {
                        response.isSuccessful -> {
                            liveDataBuku.postValue(response.body())
                        }
                        else -> {
                            liveDataBuku.postValue(null)
                        }
                    }
                }

                override fun onFailure(call: Call<List<Buku11ResponseItem>>, t: Throwable) {
                    liveDataBuku.postValue(null)
                }
            })
    }

}