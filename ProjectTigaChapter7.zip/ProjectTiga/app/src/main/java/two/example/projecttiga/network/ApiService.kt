package two.example.projecttiga.network

import retrofit2.Call
import retrofit2.http.GET
import two.example.projecttiga.model.Buku11ResponseItem

interface ApiServices {

    // get data film
    @GET("buku")
    fun getAllBuku() : Call<List<Buku11ResponseItem>>

}