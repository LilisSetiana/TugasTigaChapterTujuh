package two.example.projecttiga.model


import com.google.gson.annotations.SerializedName

class Buku11Response : ArrayList<Buku11ResponseItem>()